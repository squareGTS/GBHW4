import UIKit

//MARK - First Task & Second Task & Fourth Task
class Car {
    var model = String()
    var year = Int()
    var capacityOfTrunk = Int()
    var engine = Bool()
    var windowsOpen = Bool()
    var trunkValueOfFull = Int()
    
    func change(a: action) {
        engine = false
        windowsOpen = false
        trunkValueOfFull = 10
    }
}

class SportCar: Car {
    var highSpeed = Int()
    var hoursePower = Int()
    
    override func change(a: action) {
        engine = true
        windowsOpen = true
        highSpeed = 400
    }
}

class TrunkCar: Car {
    var numberOfWheels = Int()
    var amounOfGears = Int()
    
    override func change(a: action) {
        engine = false
        windowsOpen = true
        numberOfWheels = 8
    }
}

enum action {
    case engine(value: Bool)
    case windows(value: Bool)
    case trunk(value: Bool)
    case movement(value: Bool)
    case sportTires(value: Bool)
}

//MARK - Fifth Task
var sportCar = SportCar()
var sportCar1 = SportCar()
var trunkCar = TrunkCar()
var trunkCar1 = TrunkCar()

sportCar.capacityOfTrunk = 50
sportCar.model = "Ferrari"
trunkCar.windowsOpen = true
trunkCar.model = "Man"
trunkCar1.engine = false
trunkCar1.windowsOpen = false
sportCar1.year = 1990
sportCar1.model = "BMW"
sportCar1.change(a: action.engine(value: true))

//MARK - Sixth Task
print(sportCar)
print(sportCar1)
print(trunkCar)
print(trunkCar1)
